import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  styleUrls: ['./binding.component.css']
})
export class BindingComponent implements OnInit {


  input_text: string = '';
  input_text1: string = '';
  input_text2: string = '';
  input_text3: string = '';
  input_text4: string = '';

  constructor() { }

  ngOnInit(): void {
  }

}
